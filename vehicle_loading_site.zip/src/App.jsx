import React, { useState } from "react";
import { saveAs } from "file-saver";
import * as XLSX from "xlsx";

export default function App() {
  const [rows, setRows] = useState([]);
  const [template, setTemplate] = useState(
    "Aapki vehicle load ho rahi hai. Driver: {Driver Name} ({Driver Mobile}), Vehicle: {Vehicle Number} - Date: {Loading Date} {Loading Time}."
  );

  const handleFile = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const data = await file.arrayBuffer();
    const workbook = XLSX.read(data);
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const json = XLSX.utils.sheet_to_json(worksheet, { defval: "" });

    const normalized = json.map((r, i) => ({
      id: r['Dealer ID'] || r['DealerId'] || r['Dealer'] || `DL${i + 1}`,
      dealerName: r['Dealer Name'] || r['DealerName'] || r['Dealer'] || "",
      dealerMobile: String(r['Dealer Mobile Number'] || r['Dealer Mobile'] || r['Dealer Number'] || r['DealerPhone'] || "").replace(/\s+/g, ""),
      district: r['District'] || "",
      vehicleNumber: r['Vehicle Number'] || r['VehicleNo'] || r['Vehicle'] || "",
      driverName: r['Driver Name'] || r['Driver'] || "",
      driverMobile: String(r['Driver Mobile Number'] || r['Driver Mobile'] || r['DriverPhone'] || "").replace(/\s+/g, ""),
      loadingDate: r['Loading Date'] || r['Date'] || "",
      loadingTime: r['Loading Time'] || r['Time'] || "",
    }));

    const withMsg = normalized.map((r) => ({ ...r, message: fillTemplate(template, r) }));
    setRows(withMsg);
  };

  function fillTemplate(tpl, row) {
    return tpl
      .replaceAll('{Dealer Name}', row.dealerName || '')
      .replaceAll('{Dealer Mobile}', row.dealerMobile || '')
      .replaceAll('{Vehicle Number}', row.vehicleNumber || '')
      .replaceAll('{Driver Name}', row.driverName || '')
      .replaceAll('{Driver Mobile}', row.driverMobile || '')
      .replaceAll('{Loading Date}', row.loadingDate || '')
      .replaceAll('{Loading Time}', row.loadingTime || '');
  }

  const handleTemplateChange = (e) => {
    const t = e.target.value;
    setTemplate(t);
    setRows((prev) => prev.map((r) => ({ ...r, message: fillTemplate(t, r) })));
  };

  const sendWhatsApp = (phone, text) => {
    if (!phone) {
      alert('Dealer ka mobile number missing hai');
      return;
    }
    let p = phone.replace(/[^0-9+]/g, '');
    if (!p.startsWith('+')) {
      if (p.length === 10) p = '+91' + p;
    }
    const url = `https://api.whatsapp.com/send?phone=${encodeURIComponent(p)}&text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  const copyMessage = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      alert('Message copied to clipboard');
    } catch (e) {
      alert('Copy failed');
    }
  };

  const exportToExcel = () => {
    const ws = XLSX.utils.json_to_sheet(rows.map(r => ({
      'Dealer ID': r.id,
      'Dealer Name': r.dealerName,
      'Dealer Mobile Number': r.dealerMobile,
      'District': r.district,
      'Vehicle Number': r.vehicleNumber,
      'Driver Name': r.driverName,
      'Driver Mobile Number': r.driverMobile,
      'Loading Date': r.loadingDate,
      'Loading Time': r.loadingTime,
      'Message (Auto)': r.message,
    })));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Vehicle_Loading');
    const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([wbout], { type: 'application/octet-stream' });
    saveAs(blob, 'Vehicle_Loading_Export.xlsx');
  };

  return (
    <div style={{minHeight:'100vh', padding:24, fontFamily:'Inter, Arial'}}>
      <div style={{maxWidth:1000, margin:'auto', background:'#fff', padding:20, borderRadius:8, boxShadow:'0 4px 12px rgba(0,0,0,0.08)'}}>
        <h1 style={{fontSize:22, marginBottom:8}}>Vehicle Loading - Send Messages to Dealers</h1>
        <p style={{color:'#374151', fontSize:14}}>Excel file upload karein (first sheet) jisme Dealer aur Vehicle details hon. Use placeholders: {'{Driver Name}'}, {'{Driver Mobile}'}, {'{Vehicle Number}'}, {'{Dealer Name}'}, {'{Dealer Mobile}'}, {'{Loading Date}'}, {'{Loading Time}'}</p>

        <div style={{display:'flex', gap:10, marginTop:12, marginBottom:12}}>
          <input type="file" accept=".xlsx,.xls,.csv" onChange={handleFile} />
          <button onClick={exportToExcel} style={{padding:'8px 12px', background:'#2563eb', color:'#fff', border:'none', borderRadius:6}}>Export Excel</button>
        </div>

        <label style={{fontWeight:600}}>Message Template</label>
        <textarea value={template} onChange={handleTemplateChange} rows={3} style={{width:'100%', padding:10, marginTop:8, marginBottom:12}} />

        <div style={{overflowX:'auto'}}>
          <table style={{width:'100%', borderCollapse:'collapse'}}>
            <thead>
              <tr style={{background:'#f3f4f6', textAlign:'left'}}>
                <th style={{padding:8, border:'1px solid #e5e7eb'}}>#</th>
                <th style={{padding:8, border:'1px solid #e5e7eb'}}>Dealer</th>
                <th style={{padding:8, border:'1px solid #e5e7eb'}}>Dealer Mobile</th>
                <th style={{padding:8, border:'1px solid #e5e7eb'}}>Vehicle</th>
                <th style={{padding:8, border:'1px solid #e5e7eb'}}>Driver</th>
                <th style={{padding:8, border:'1px solid #e5e7eb'}}>Date / Time</th>
                <th style={{padding:8, border:'1px solid #e5e7eb'}}>Message</th>
                <th style={{padding:8, border:'1px solid #e5e7eb'}}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 && (
                <tr><td colSpan={8} style={{padding:16, textAlign:'center', color:'#6b7280'}}>Koi data nahi mila. Excel upload karein ya sample add karein.</td></tr>
              )}
              {rows.map((r, idx) => (
                <tr key={idx} style={{background: idx%2? '#fff':'#f9fafb'}}>
                  <td style={{padding:8, border:'1px solid #e5e7eb', verticalAlign:'top'}}>{idx + 1}</td>
                  <td style={{padding:8, border:'1px solid #e5e7eb', verticalAlign:'top'}}>{r.dealerName}</td>
                  <td style={{padding:8, border:'1px solid #e5e7eb', verticalAlign:'top'}}>{r.dealerMobile}</td>
                  <td style={{padding:8, border:'1px solid #e5e7eb', verticalAlign:'top'}}>{r.vehicleNumber}</td>
                  <td style={{padding:8, border:'1px solid #e5e7eb', verticalAlign:'top'}}>{r.driverName} <br/> {r.driverMobile}</td>
                  <td style={{padding:8, border:'1px solid #e5e7eb', verticalAlign:'top'}}>{r.loadingDate} {r.loadingTime}</td>
                  <td style={{padding:8, border:'1px solid #e5e7eb', verticalAlign:'top', whiteSpace:'pre-wrap'}}>{r.message}</td>
                  <td style={{padding:8, border:'1px solid #e5e7eb', verticalAlign:'top', display:'flex', flexDirection:'column', gap:6}}>
                    <button onClick={() => sendWhatsApp(r.dealerMobile, r.message)} style={{padding:'6px 8px', background:'#16a34a', color:'#fff', border:'none', borderRadius:6}}>WhatsApp</button>
                    <button onClick={() => copyMessage(r.message)} style={{padding:'6px 8px', background:'#374151', color:'#fff', border:'none', borderRadius:6}}>Copy</button>
                    <a style={{display:'inline-block', padding:'6px 8px', background:'#4f46e5', color:'#fff', borderRadius:6, textDecoration:'none'}} href={`sms:${r.dealerMobile}?body=${encodeURIComponent(r.message)}`}>Send SMS</a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div style={{marginTop:16, color:'#6b7280', fontSize:13}}>
          <strong>Note:</strong> WhatsApp link opens WhatsApp Web / App. SMS link works on phones. Website is frontend-only — agar aap chahte hain ki messages automatically send ho bina user interaction ke, to backend SMS/WhatsApp provider (Twilio, Gupshup, etc.) ki zarurat padegi aur uske liye API keys chahiye honge.
        </div>
      </div>
    </div>
  );
}
