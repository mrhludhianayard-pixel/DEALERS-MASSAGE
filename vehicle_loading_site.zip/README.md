# Vehicle Loading App (Frontend)
This is a minimal React frontend that reads an Excel/CSV file with dealer & vehicle details and generates messages for each row. It allows sending messages via WhatsApp link or copying the message.

## How to run (on your computer)
1. Unzip the folder.
2. In the project folder, run:
   ```
   npm install
   npm start
   ```
3. Open http://localhost:3000 in your browser.

Note: This is frontend only. For automatic sending you will need a backend and an SMS/WhatsApp provider (e.g., Twilio, Gupshup).
